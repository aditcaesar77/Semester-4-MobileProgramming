package com.example.uasmobile;


import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TambahDataPelanggan extends AppCompatActivity {
    protected Cursor cursor;
    DatabaseHelper dbHelper;
    Button buttonSimpan;
    EditText editTextID, editTextNama_pelanggan, editTextNotlp, editTextAlamat, editTextEmail;
    String edit;
    //TextView textViewNomor, textViewNama, textViewTanggalLahir, textViewJenisKelamin, textViewAlamat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_data_pelanggan);

        dbHelper = new DatabaseHelper(this);

        editTextID = findViewById(R.id.edit_text_ID);
        editTextNama_pelanggan = findViewById(R.id.edit_text_nama_pelanggan);
        editTextNotlp = findViewById(R.id.edit_text_notlp);
        editTextAlamat = findViewById(R.id.edit_text_alamat);
        editTextEmail = findViewById(R.id.edit_text_email);

        buttonSimpan = findViewById(R.id.button_simpan);

        buttonSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                edit = editTextID.getText().toString();
                edit = editTextNama_pelanggan.getText().toString();
                edit = editTextNotlp.getText().toString();
                edit = editTextAlamat.getText().toString();
                edit = editTextEmail.getText().toString();

                if (edit.isEmpty()) { //cek text box kosong
                    Toast.makeText(getApplicationContext(), "Kolom tidak boleh kosong...", Toast.LENGTH_SHORT).show();
                } else {                           //nama field di tabel
                    db.execSQL("insert into pelanggan(id_pelanggan, nama, no_tlp, alamat, email) values('" +
                            editTextID.getText().toString() + "','" +
                            editTextNama_pelanggan.getText().toString() +"','" +
                            editTextNotlp.getText().toString() + "','" +
                            editTextAlamat.getText().toString() + "','" +
                            editTextEmail.getText().toString() + "')");
                    Toast.makeText(getApplicationContext(), "Data Tersimpan...", Toast.LENGTH_SHORT).show();
                    finish();
                }
                lihatdatapelanggan.dm.refreshList();
            }
        });

    }
}