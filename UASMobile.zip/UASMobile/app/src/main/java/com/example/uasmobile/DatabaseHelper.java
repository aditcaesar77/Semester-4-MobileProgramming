package com.example.uasmobile;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "wearshopid.db";
    private static final int DATABASE_VERSION = 1;


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Membuat tabel barang
        String sql = "CREATE TABLE barang (id_produk INTEGER PRIMARY KEY, nama_produk TEXT, brand TEXT, stok INTEGER, release_date TEXT, size INTEGER, harga INTEGER);";
        Log.d("Data", "onCreate: " + sql);
        db.execSQL(sql);

        // Membuat tabel pelanggan
        sql = "CREATE TABLE  pelanggan (id_pelanggan INTEGER PRIMARY KEY, nama TEXT, no_tlp INTEGER, alamat TEXT, email TEXT);";
        Log.d("Data", "onCreate: " + sql);
        db.execSQL(sql);

        // Menambahkan data ke tabel barang
        sql = "INSERT INTO barang (id_produk, nama_produk, brand, stok, release_date, size, harga) VALUES ('1', 'Adidas Campus 00s YNuK Brown Desert', 'Adidas', '1', '2019', '43', '2500000');";
        db.execSQL(sql);

        // Menambahkan data ke tabel pelanggan
        sql = "INSERT INTO pelanggan (id_pelanggan, nama, no_tlp, alamat, email) VALUES ('1', 'John Doe', '089838234823', 'denpasar', 'john@gmail.com');";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
        // Kode ini akan dieksekusi saat melakukan upgrade database, seperti mengubah versi database atau skema tabel
        // Anda dapat mengimplementasikan logika yang sesuai untuk mengelola upgrade database.
    }
}

