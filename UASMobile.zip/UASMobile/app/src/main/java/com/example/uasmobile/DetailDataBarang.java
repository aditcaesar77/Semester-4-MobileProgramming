package com.example.uasmobile;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DetailDataBarang extends AppCompatActivity {

    protected Cursor cursor;
    DatabaseHelper dbHelper;
    TextView textViewID, textViewNama_produk, textViewBrand, textViewStok, textViewRelease, textViewSize, textViewHarga;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_data_barang);

        dbHelper = new DatabaseHelper(this);

        textViewID = findViewById(R.id.text_view_ID_detail);
        textViewNama_produk = findViewById(R.id.text_view_nama_produk_detail);
        textViewBrand = findViewById(R.id.text_view_brand_detail);
        textViewStok = findViewById(R.id.text_view_stok_detail);
        textViewRelease = findViewById(R.id.text_view_release_detail);
        textViewSize = findViewById(R.id.text_view_size_detail);
        textViewHarga = findViewById(R.id.text_view_harga_detail);

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM barang WHERE nama_produk = '" + getIntent().getStringExtra("nama_produk") + "'", null);
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            cursor.moveToPosition(0);
            textViewID.setText(cursor.getString(0).toString());
            textViewNama_produk.setText(cursor.getString(1).toString());
            textViewBrand.setText(cursor.getString(2).toString());
            textViewStok.setText(cursor.getString(3).toString());
            textViewRelease.setText(cursor.getString(4).toString());
            textViewSize.setText(cursor.getString(4).toString());
            textViewHarga.setText(cursor.getString(4).toString());
        }
    }
}