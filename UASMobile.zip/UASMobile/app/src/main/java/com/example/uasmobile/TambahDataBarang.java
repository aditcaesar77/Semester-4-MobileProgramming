package com.example.uasmobile;


import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TambahDataBarang extends AppCompatActivity {
    protected Cursor cursor;
    DatabaseHelper dbHelper;
    Button buttonSimpan;
    EditText editTextID, editTextNama_produk, editTextBrand, editTextStok, editTextRelease, editTextSize, editTextHarga;
    String edit;
    //TextView textViewNomor, textViewNama, textViewTanggalLahir, textViewJenisKelamin, textViewAlamat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_data_barang);

        dbHelper = new DatabaseHelper(this);

        editTextID = findViewById(R.id.edit_text_ID);
        editTextNama_produk = findViewById(R.id.edit_text_nama_produk);
        editTextBrand = findViewById(R.id.edit_text_brand);
        editTextStok = findViewById(R.id.edit_text_stok);
        editTextRelease = findViewById(R.id.edit_text_release);
        editTextSize = findViewById(R.id.edit_text_size);
        editTextHarga = findViewById(R.id.edit_text_harga);

        buttonSimpan = findViewById(R.id.button_simpan);

        buttonSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                edit = editTextID.getText().toString();
                edit = editTextNama_produk.getText().toString();
                edit = editTextBrand.getText().toString();
                edit = editTextStok.getText().toString();
                edit = editTextRelease.getText().toString();
                edit = editTextSize.getText().toString();
                edit = editTextHarga.getText().toString();

                if (edit.isEmpty()) { //cek text box kosong
                    Toast.makeText(getApplicationContext(), "Kolom tidak boleh kosong...", Toast.LENGTH_SHORT).show();
                } else {                           //nama field di tabel
                    db.execSQL("insert into barang(id_produk, nama_produk, brand, stok, release_date, size, harga) values('" +
                            editTextID.getText().toString() + "','" +
                            editTextNama_produk.getText().toString() +"','" +
                            editTextBrand.getText().toString() + "','" +
                            editTextStok.getText().toString() + "','" +
                            editTextRelease.getText().toString() + "','" +
                            editTextSize.getText().toString() +"','" +
                            editTextHarga.getText().toString() +"')");
                    Toast.makeText(getApplicationContext(), "Data Tersimpan...", Toast.LENGTH_SHORT).show();
                    finish();
                }
                lihatdatabarang.dm.refreshList();
            }
        });

    }
}