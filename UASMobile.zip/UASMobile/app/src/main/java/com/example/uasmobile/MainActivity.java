package com.example.uasmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    Button btnlihatbarang, btnlihatpelanggan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnlihatbarang = findViewById(R.id.btlihatbarang);
        btnlihatpelanggan = findViewById(R.id.btlihatpelanggan);

        btnlihatbarang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(MainActivity.this, lihatdatabarang.class);
                startActivity(a);
            }
        });

        btnlihatpelanggan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(MainActivity.this, lihatdatapelanggan.class);
                startActivity(a);
            }
        });
    }
}