package com.example.uasmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class UpdateDataBarang extends AppCompatActivity {

    protected Cursor cursor;
    DatabaseHelper dbHelper;
    Button buttonSimpan;
    EditText editTextID, editTextNama_produk, editTextBrand, editTextStok, editTextRelease, editTextSize, editTextHarga;
    String edit;
    //TextView textViewNomor, textViewNama, textViewTanggalLahir, textViewJenisKelamin, textViewAlamat;
    lihatdatabarang lh = new lihatdatabarang();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_data_barang);

        dbHelper = new DatabaseHelper(this);

        editTextID = findViewById(R.id.edit_text_ID);
        editTextNama_produk = findViewById(R.id.edit_text_nama_produk);
        editTextBrand = findViewById(R.id.edit_text_brand);
        editTextStok = findViewById(R.id.edit_text_stok);
        editTextRelease = findViewById(R.id.edit_text_release);
        editTextSize = findViewById(R.id.edit_text_size);
        editTextHarga = findViewById(R.id.edit_text_harga);

//        textViewNomor = findViewById(R.id.text_view_nomor);
//        textViewNama = findViewById(R.id.text_view_nama);
//        textViewTanggalLahir = findViewById(R.id.text_view_tanggal_lahir);
//        textViewJenisKelamin = findViewById(R.id.text_view_jenis_kelamin);
//        textViewAlamat = findViewById(R.id.text_view_alamat);

        buttonSimpan = findViewById(R.id.button_simpan);

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        //query untuk mengambil data dari tabel berdasarkan nama
        cursor = db.rawQuery("SELECT * FROM barang WHERE nama_produk = '" + getIntent().getStringExtra("nama_produk") + "'", null);
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            cursor.moveToPosition(0);
            editTextID.setText(cursor.getString(0).toString());
            editTextNama_produk.setText(cursor.getString(1).toString());
            editTextBrand.setText(cursor.getString(2).toString());
            editTextStok.setText(cursor.getString(3).toString());
            editTextRelease.setText(cursor.getString(4).toString());
            editTextSize.setText(cursor.getString(5).toString());
            editTextHarga.setText(cursor.getString(6).toString());

        }

        buttonSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                edit = editTextID.getText().toString();
                edit = editTextNama_produk.getText().toString();
                edit = editTextBrand.getText().toString();
                edit = editTextStok.getText().toString();
                edit = editTextRelease.getText().toString();
                edit = editTextSize.getText().toString();
                edit = editTextHarga.getText().toString();

                if (edit.isEmpty()) { //untuk tek kolom kosong
                    Toast.makeText(getApplicationContext(), "Kolom tidak boleh kosong...", Toast.LENGTH_SHORT).show();
                } else { //query untuk melakukan update data di tabel
                    db.execSQL("update barang set nama_produk='" +
                            editTextNama_produk.getText().toString() + "', brand='" +
                            editTextBrand.getText().toString() + "', stok='" +
                            editTextStok.getText().toString() + "', release_date='" +
                            editTextRelease.getText().toString() + "', size='" + editTextSize.getText().toString() + "', harga='" + editTextHarga.getText().toString() + "' where id_produk='" +
                            editTextID.getText().toString() + "'");
                    //update biodata set nama = 'Ayu', tgl = '1 januari 2000', jk = 'p', alamat = 'Denpasar' where no = '123'
                    Toast.makeText(getApplicationContext(), "Perubahan Tersimpan...", Toast.LENGTH_LONG).show();
                    finish();
                }
                //refresh();
                lihatdatabarang.dm.refreshList();
                //lh.refreshList();

            }
        });
    }

}