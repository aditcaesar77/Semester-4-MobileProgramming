package com.example.uasmobile;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DetailDataPelanggan extends AppCompatActivity {

    protected Cursor cursor;
    DatabaseHelper dbHelper;
    TextView textViewID, textViewNama_pelanggan, textViewNotlp, textViewAlamat, textViewEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_data_pelanggan);

        dbHelper = new DatabaseHelper(this);

        textViewID = findViewById(R.id.text_view_ID_detail);
        textViewNama_pelanggan = findViewById(R.id.text_view_nama_detail);
        textViewNotlp = findViewById(R.id.text_view_notlp_detail);
        textViewAlamat = findViewById(R.id.text_view_alamat_detail);
        textViewEmail = findViewById(R.id.text_view_email_detail);

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM pelanggan WHERE nama = '" + getIntent().getStringExtra("nama") + "'", null);
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            cursor.moveToPosition(0);
            textViewID.setText(cursor.getString(0).toString());
            textViewNama_pelanggan.setText(cursor.getString(1).toString());
            textViewNotlp.setText(cursor.getString(2).toString());
            textViewAlamat.setText(cursor.getString(3).toString());
            textViewEmail.setText(cursor.getString(4).toString());
        }
    }
}