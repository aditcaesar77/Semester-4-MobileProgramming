package com.example.uasmobile;


import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class UpdateDataPelanggan extends AppCompatActivity {

    protected Cursor cursor;
    DatabaseHelper dbHelper;
    Button buttonSimpan;
    EditText editTextID, editTextNama_pelanggan, editTextNotlp, editTextAlamat, editTextEmail;
    String edit;
    //TextView textViewNomor, textViewNama, textViewTanggalLahir, textViewJenisKelamin, textViewAlamat;
    lihatdatabarang lh = new lihatdatabarang();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_data_pelanggan);

        dbHelper = new DatabaseHelper(this);

        editTextID = findViewById(R.id.edit_text_ID);
        editTextNama_pelanggan = findViewById(R.id.edit_text_nama_pelanggan);
        editTextNotlp = findViewById(R.id.edit_text_notlp);
        editTextAlamat = findViewById(R.id.edit_text_alamat);
        editTextEmail = findViewById(R.id.edit_text_email);

//        textViewNomor = findViewById(R.id.text_view_nomor);
//        textViewNama = findViewById(R.id.text_view_nama);
//        textViewTanggalLahir = findViewById(R.id.text_view_tanggal_lahir);
//        textViewJenisKelamin = findViewById(R.id.text_view_jenis_kelamin);
//        textViewAlamat = findViewById(R.id.text_view_alamat);

        buttonSimpan = findViewById(R.id.button_simpan);

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        //query untuk mengambil data dari tabel berdasarkan nama
        cursor = db.rawQuery("SELECT * FROM pelanggan WHERE nama = '" + getIntent().getStringExtra("nama") + "'", null);
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            cursor.moveToPosition(0);
            editTextID.setText(cursor.getString(0).toString());
            editTextNama_pelanggan.setText(cursor.getString(1).toString());
            editTextNotlp.setText(cursor.getString(2).toString());
            editTextAlamat.setText(cursor.getString(3).toString());
            editTextEmail.setText(cursor.getString(4).toString());

        }

        buttonSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                edit = editTextID.getText().toString();
                edit = editTextNama_pelanggan.getText().toString();
                edit = editTextNotlp.getText().toString();
                edit = editTextAlamat.getText().toString();
                edit = editTextEmail.getText().toString();

                if (edit.isEmpty()) { //untuk tek kolom kosong
                    Toast.makeText(getApplicationContext(), "Kolom tidak boleh kosong...", Toast.LENGTH_SHORT).show();
                } else { //query untuk melakukan update data di tabel
                    db.execSQL("update barang set nama='" +
                            editTextNama_pelanggan.getText().toString() + "', no_tlp='" +
                            editTextNotlp.getText().toString() + "', alamat='" +
                            editTextAlamat.getText().toString() + "', email='" +
                            editTextEmail.getText().toString() + "' where id_pelanggan='" +
                            editTextID.getText().toString() + "'");
                    //update biodata set nama = 'Ayu', tgl = '1 januari 2000', jk = 'p', alamat = 'Denpasar' where no = '123'
                    Toast.makeText(getApplicationContext(), "Perubahan Tersimpan...", Toast.LENGTH_LONG).show();
                    finish();
                }
                //refresh();
                lihatdatapelanggan.dm.refreshList();
                //lh.refreshList();

            }
        });
    }

}