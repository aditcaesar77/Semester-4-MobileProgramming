package com.dwigasu.cruddata;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UpdateDataMahasiswa extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_data_mahasiswa);
    }
}