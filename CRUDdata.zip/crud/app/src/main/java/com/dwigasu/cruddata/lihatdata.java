package com.dwigasu.cruddata;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class lihatdata extends AppCompatActivity {

    String[] daftar;
    ListView listView;
    Menu menu;
    protected Cursor cursor;
    DatabaseHelper dbCenter;
    public static lihatdata dm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lihatdata);

        Button buttonInputDataMahasiswa = findViewById(R.id.button_input_data_mahasiswa);

        buttonInputDataMahasiswa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentInputData = new Intent(lihatdata.this, TambahData.class);
                startActivity(intentInputData);
            }
        });

        dm = this;
        dbCenter = new DatabaseHelper(this);
        refreshList();
    }

    public void refreshList() {
        //creating object db dari class sqllite
        SQLiteDatabase db = dbCenter.getReadableDatabase();
        //menampilkan semua data dari tabel biodata
        cursor = db.rawQuery("SELECT * FROM biodata", null);
        daftar = new String[cursor.getCount()];
        cursor.moveToFirst();

        //menyimpan  data  dari database/tabel ke array daftar
        for (int cc = 0; cc < cursor.getCount(); cc++) {
            cursor.moveToPosition(cc);
            daftar[cc] = cursor.getString(1).toString();
        }

        listView = findViewById(R.id.list_view_data_mahasiswa);
        //menampilkan data array ke listview
        listView.setAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1, daftar));
        listView.setSelected(true);
        //pada saat listview di klik
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final  String selection = daftar[position];
                final CharSequence[] dialogItem = {"Lihat Data", "Update Data", "Hapus Data"};
                AlertDialog.Builder builder = new AlertDialog.Builder(lihatdata.this);
                builder.setTitle("Pilihan");
                builder.setItems(dialogItem, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                Intent intentDetailData = new Intent(getApplicationContext(), DetailDataMahasiswa.class);
                                intentDetailData.putExtra("nama", selection);
                                startActivity(intentDetailData);
                                break;
                            case  1:
                                Intent intentUpdateData = new Intent(getApplicationContext(), UpdateDataMahasiswa.class);
                                intentUpdateData.putExtra("nama", selection);
                                startActivity(intentUpdateData);
                                break;
                            case 2:
                                SQLiteDatabase db = dbCenter.getWritableDatabase();
                                db.execSQL("delete from biodata where nama = '"+selection+"'");
                                refreshList();
                                break;
                        }
                    }
                });
                builder.create().show();
            }
        });
        ((ArrayAdapter) listView.getAdapter()).notifyDataSetInvalidated();
    }
}